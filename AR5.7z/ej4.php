<!DOCTYPE html>
<html>
<head>
    <title>ej4</title>
</head>
<body>
    <h1>ej4</h1>
    <?php


$city = "Tokyo, Mexico City, New York City, Mumbai, Seoul, Shanghai, Lagos, Buenos Aires, Cairo, London";
$country = "Japan, Mexico, USA, India, Korea, China, Nigeria, Argentina, Egypt, England";

$cityArray = explode(",", $city);
$countryArray = explode(",", $country);

$resultadoArray = [];

for ($i = 0; $i < count($cityArray); $i++) {
    $resultadoArray[] = ['city' => $cityArray[$i], 'country' => $countryArray[$i]];
}

echo "<pre>";
var_dump($resultadoArray);


?>

</body>
</html>