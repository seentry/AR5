<!DOCTYPE html>
<html>
<head>
    <title>ej5</title>
</head>
<body>
    <h1>ej5</h1>
    <?php


$data = "Tokyo, Japan; Mexico City, Mexico; New York City, USA; Mumbai, India; Seoul, Korea; Shanghai, China; Lagos, Nigeria; Buenos Aires, Argentina; Cairo, Egypt; London, England";
$dataArray = ["Tokyo, Japan; Mexico City, Mexico; New York City, USA; Mumbai, India; Seoul, Korea; Shanghai, China; Lagos, Nigeria; Buenos Aires, Argentina; Cairo, Egypt; London, England"];


foreach ($dataArray as $pareja) {
    $capitales = explode $pareja
}

echo "<pre>";
var_dump($resultadoArray);



?>

</body>
</html>